# VisualCore — RenderForge Create API GPU Integration

Seedream/Seedance/Ideogram API 비용을 로컬 GPU 추론으로 대체하는 RenderForge 내장 모듈.

## 비용 절감

| | API (현행) | VisualCore | 절감 |
|---|---|---|---|
| 이미지 (Seedream) | $841/월 | $0 | 100% |
| 영상 (Seedance) | $137/월 | $27 (20% API) | 80% |
| 썸네일 (Ideogram) | $94/월 | $0 | 100% |
| GPU (RunPod) | — | $23 | — |
| **합계 (Scale2)** | **$1,072** | **$50** | **95%** |

## 파일 구조

```
src/create/
├── providers/
│   ├── types.ts           # 인터페이스, 타입, 해상도 헬퍼
│   ├── router.ts          # Provider 라우팅 (Flux/Hunyuan/Seedance)
│   ├── flux-klein.ts      # ComfyUI WebSocket 연동 (이미지)
│   ├── hunyuan-local.ts   # HunyuanVideo REST API (영상)
│   ├── seedance-remote.ts # Seedance API fallback (핵심 씬)
│   ├── realesrgan.ts      # Real-ESRGAN 업스케일
│   └── index.ts           # Barrel export
├── gpu/
│   └── memory-manager.ts  # GPU VRAM 모델 스왑 관리
├── qc/
│   └── pipeline.ts        # CLIP Score + Aesthetic + 자동 재생성
└── queue/
    └── create-jobs.ts     # BullMQ 큐 + 배치 최적화

docker/
├── docker-compose.gpu.yml # 전체 GPU 스택 (RF + ComfyUI + Hunyuan + VoiceCore)
└── hunyuan/
    ├── Dockerfile         # HunyuanVideo 1.5 컨테이너
    └── server.py          # FastAPI REST 래퍼

tests/
└── visualcore.test.ts     # Vitest 단위 테스트

.env.template              # 환경변수 템플릿
```

## RenderForge 머지 방법

```bash
# 1. RenderForge 리포에서
cp -r visualcore/src/create/providers/ src/create/providers/
cp -r visualcore/src/create/gpu/ src/create/gpu/
cp -r visualcore/src/create/qc/ src/create/qc/
cp -r visualcore/src/create/queue/ src/create/queue/

# 2. Docker 파일 추가
cp visualcore/docker/docker-compose.gpu.yml docker/
cp -r visualcore/docker/hunyuan/ docker/hunyuan/

# 3. 환경변수 머지
cat visualcore/.env.template >> .env

# 4. 테스트
cp visualcore/tests/visualcore.test.ts tests/
pnpm test

# 5. logger import 경로 조정
# 각 파일의 import { logger } from '../../config/logger.js'를
# RenderForge 실제 logger 경로로 변경
```

## 라우팅 로직

```
POST /create/v1/generate
  ↓
ProviderRouter
  ├── type: text-to-image → FluxKleinProvider (ComfyUI, port 8188)
  ├── type: image-to-video
  │   ├── priority: high → SeedanceRemoteProvider (API)
  │   └── priority: normal → HunyuanLocalProvider (port 8190)
  └── type: upscale → RealEsrganProvider (CLI)
```

## GPU 메모리 관리

RTX 4090 (24GB) 기준, 동시 로딩 불가한 모델은 자동 스왑:

```
Fish Speech (2GB) ← 항상 상주
Flux Klein (8GB)  ← 이미지 생성 시 로딩
HunyuanVideo (14GB) ← 영상 생성 시 로딩 (Flux와 교체)
```

## 품질 검수 (QC)

1. 생성 → 2. CLIP Score + Aesthetic 측정 → 3. 임계값 미달 시 시드 변경 재생성 (최대 3회) → 4. 전부 실패 시 Seedream/Seedance API fallback

## 의존성

```json
{
  "ws": "^8.0.0",
  "bullmq": "^5.0.0"
}
```

Python (QC용): `transformers`, `torch`, `Pillow`  
System: `ffmpeg`, `ffprobe`, `realesrgan-ncnn-vulkan`
