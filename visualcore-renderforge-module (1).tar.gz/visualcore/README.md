# VisualCore — RenderForge Create API GPU Integration

Seedream/Seedance/Ideogram API 비용을 로컬 GPU 추론으로 대체하는 RenderForge 내장 모듈.

## 비용 절감

| | API (현행) | VisualCore | 절감 |
|---|---|---|---|
| 이미지 (Seedream) | $841/월 | $0 | 100% |
| 영상 (Seedance) | $137/월 | $27 (20% API) | 80% |
| 썸네일 (Ideogram) | $94/월 | $0 | 100% |
| GPU (RunPod) | — | $23 | — |
| **합계 (Scale2)** | **$1,072** | **$50** | **95%** |

## 파일 구조

```
src/create/
├── providers/
│   ├── types.ts           # 인터페이스, 타입, 해상도 헬퍼
│   ├── router.ts          # Provider 라우팅 (Flux/Hunyuan/Seedance)
│   ├── flux-klein.ts      # ComfyUI WebSocket 연동 (이미지)
│   ├── hunyuan-local.ts   # HunyuanVideo REST API (영상)
│   ├── seedance-remote.ts # Seedance API fallback (핵심 씬)
│   ├── realesrgan.ts      # Real-ESRGAN 업스케일
│   └── index.ts           # Barrel export
├── gpu/
│   └── memory-manager.ts  # GPU VRAM 모델 스왑 관리
├── qc/
│   └── pipeline.ts        # CLIP Score + Aesthetic + 자동 재생성
└── queue/
    └── create-jobs.ts     # BullMQ 큐 + 배치 최적화

docker/
├── docker-compose.gpu.yml # 전체 GPU 스택 (RF + ComfyUI + Hunyuan + VoiceCore)
└── hunyuan/
    ├── Dockerfile         # HunyuanVideo 1.5 컨테이너
    └── server.py          # FastAPI REST 래퍼

tests/
└── visualcore.test.ts     # Vitest 단위 테스트

.env.template              # 환경변수 템플릿
```

## RenderForge 머지 방법

```bash
# 1. RenderForge 리포에서
cp -r visualcore/src/create/providers/ src/create/providers/
cp -r visualcore/src/create/gpu/ src/create/gpu/
cp -r visualcore/src/create/qc/ src/create/qc/
cp -r visualcore/src/create/queue/ src/create/queue/

# 2. Docker 파일 추가
cp visualcore/docker/docker-compose.gpu.yml docker/
cp -r visualcore/docker/hunyuan/ docker/hunyuan/

# 3. 환경변수 머지
cat visualcore/.env.template >> .env

# 4. 테스트
cp visualcore/tests/visualcore.test.ts tests/
pnpm test

# 5. logger import 경로 조정
# 각 파일의 import { logger } from '../../config/logger.js'를
# RenderForge 실제 logger 경로로 변경
```

## 라우팅 로직

```
POST /create/v1/generate
  ↓
ProviderRouter
  ├── type: text-to-image → FluxKleinProvider (ComfyUI, port 8188)
  ├── type: image-to-video
  │   ├── priority: high → SeedanceRemoteProvider (API)
  │   └── priority: normal → HunyuanLocalProvider (port 8190)
  └── type: upscale → RealEsrganProvider (CLI)
```

## GPU 메모리 관리

RTX 4090 (24GB) 기준, 동시 로딩 불가한 모델은 자동 스왑:

```
Fish Speech (2GB) ← 항상 상주
Flux Klein (8GB)  ← 이미지 생성 시 로딩
HunyuanVideo (14GB) ← 영상 생성 시 로딩 (Flux와 교체)
```

## 품질 검수 (QC)

1. 생성 → 2. CLIP Score + Aesthetic 측정 → 3. 임계값 미달 시 시드 변경 재생성 (최대 3회) → 4. 전부 실패 시 Seedream/Seedance API fallback

## 스펙 문서 목차

`VisualCore_RenderForge_Integration_Spec.md` (21개 섹션):

| # | 섹션 | 내용 |
|---|------|------|
| 1 | 현재 상태 분석 | 270ch 월간 소비량, Phase별 수량 |
| 2 | 대체 모델 선정 | Flux Klein / HunyuanVideo / 품질 비교 |
| 3 | GPU 인프라 설계 | VRAM 예산, 스왑 전략, GPU 시간 산출 |
| 4 | Create API 변경 설계 | ProviderRouter, 각 Provider 코드 |
| 5 | BullMQ 큐 설계 | 우선순위, 배치 최적화 |
| 6 | 니치별 LoRA 전략 | 9티어 프리셋, 학습 사양 |
| 7 | N8N 워크플로우 변경 | WF-VISUAL 통합, HTTP Request 설정 |
| 8 | 품질 자동 검수 | CLIP Score, Aesthetic, 재생성 로직 |
| 9 | Docker Compose | 전체 GPU 스택 설정 |
| 10 | 환경변수 설정 | .env 전체 항목 |
| 11 | 구현 로드맵 | Phase 0~4 체크리스트 |
| 12 | 비용 최종 요약 | 월간, 3년 TCO, 전체 인프라 절감 |
| 13 | 리스크 및 완화 | 8개 리스크 매트릭스 |
| **14** | **모델 다운로드 및 초기 설정** | HuggingFace 명령어, 파일 크기, 라이선스, ComfyUI 초기화, QC 의존성 |
| **15** | **RunPod 인스턴스 설정** | 스펙 선택, SSH 설정 절차, 자체 서버 전환 판단 기준 |
| **16** | **RenderForge 머지 상세 절차** | 파일 복사, import 수정, 의존성, 기존 API 연결, Git 커밋 |
| **17** | **LoRA 학습 절차** | 데이터 수집 소스/장수, 자동 캡셔닝 스크립트, Kohya 학습 명령, 배치 자동화 |
| **18** | **PoC 테스트 계획** | Beyond Orbit 1편 A/B 비교, 합격 기준, 실행 명령 |
| **19** | **N8N 워크플로우 마이그레이션** | 기존→통합 구조, URL 변경점, visual_priority 태그 규칙 |
| **20** | **모니터링 및 비용 추적** | Prometheus 메트릭, 월간 리포트 템플릿 |
| **21** | **마스터 플랜 재무제표 반영** | 수정 대상 파일, 변경 금액, CONTINUATION JSON 키, GitHub 전략 |

## 의존성

```json
{
  "ws": "^8.0.0",
  "bullmq": "^5.0.0"
}
```

Python (QC용): `transformers`, `torch`, `Pillow`, `open-clip-torch`  
System: `ffmpeg`, `ffprobe`, `realesrgan-ncnn-vulkan`
